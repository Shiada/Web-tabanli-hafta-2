/**
 * BEUShareBox Pro - Main Application Logic
 */

// --- State Management ---
let products = [];
let theme = localStorage.getItem('beu_theme') || 'light';
let currentImageBase64 = null;

// --- DOM Elements ---
const productForm = document.getElementById('product-form');
const productList = document.getElementById('product-list');
const emptyState = document.getElementById('empty-state');
const searchInput = document.getElementById('search-input');
const categoryFilter = document.getElementById('category-filter');
const sortSelect = document.getElementById('sort-select');
const imageInput = document.getElementById('image');
const imagePreview = document.getElementById('image-preview');
const themeToggle = document.getElementById('theme-toggle');
const toastContainer = document.getElementById('toast-container');

// Stats Elements
const statTotal = document.getElementById('stat-total');
const statLikes = document.getElementById('stat-likes');
const statTop = document.getElementById('stat-top');
const statCategories = document.getElementById('stat-categories');

// --- Initialization ---
function init() {
  applyTheme(theme);
  loadProducts();
  setupEventListeners();
  render();
}

// --- Local Storage ---
function loadProducts() {
  const stored = localStorage.getItem('beu_products_pro');
  if (stored) {
    try {
      products = JSON.parse(stored);
    } catch (e) {
      console.error('Error parsing stored products', e);
      products = [];
    }
  }
}

function saveProducts() {
  localStorage.setItem('beu_products_pro', JSON.stringify(products));
}

// --- Event Listeners ---
function setupEventListeners() {
  productForm.addEventListener('submit', handleAddProduct);
  searchInput.addEventListener('input', render);
  categoryFilter.addEventListener('change', render);
  sortSelect.addEventListener('change', render);
  productList.addEventListener('click', handleProductActions);
  productList.addEventListener('submit', handleAddComment);
  themeToggle.addEventListener('click', toggleTheme);
  imageInput.addEventListener('change', handleImageUpload);
}

// --- Theme Management ---
function toggleTheme() {
  theme = theme === 'light' ? 'dark' : 'light';
  localStorage.setItem('beu_theme', theme);
  applyTheme(theme);
}

function applyTheme(currentTheme) {
  document.documentElement.setAttribute('data-theme', currentTheme);
  const icon = document.getElementById('theme-icon');
  if (currentTheme === 'dark') {
    // Moon icon
    icon.innerHTML = `<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>`;
  } else {
    // Sun icon
    icon.innerHTML = `<circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>`;
  }
}

// --- Image Upload (FileReader API) ---
function handleImageUpload(e) {
  const file = e.target.files[0];
  if (!file) {
    currentImageBase64 = null;
    imagePreview.classList.add('hidden');
    return;
  }

  // Check file size (limit to ~2MB to avoid localStorage quota issues)
  if (file.size > 2 * 1024 * 1024) {
    showToast('Image too large. Please select an image under 2MB.', 'error');
    imageInput.value = '';
    return;
  }

  const reader = new FileReader();
  reader.onload = function(event) {
    currentImageBase64 = event.target.result;
    imagePreview.style.backgroundImage = `url(${currentImageBase64})`;
    imagePreview.classList.remove('hidden');
  };
  reader.readAsDataURL(file);
}

// --- Handlers ---
function handleAddProduct(e) {
  e.preventDefault();
  
  const title = document.getElementById('title').value.trim();
  const description = document.getElementById('description').value.trim();
  const price = parseFloat(document.getElementById('price').value);
  const category = document.getElementById('category').value;
  const url = document.getElementById('url').value.trim();
  
  if (!title || !description || isNaN(price) || !category) {
    showToast('Please fill in all required fields.', 'error');
    return;
  }
  
  const newProduct = {
    id: Date.now().toString(),
    title,
    description,
    price,
    category,
    url,
    image: currentImageBase64,
    likes: 0,
    comments: [],
    createdAt: new Date().toISOString()
  };
  
  products.unshift(newProduct);
  saveProducts();
  
  // Reset form
  productForm.reset();
  currentImageBase64 = null;
  imagePreview.classList.add('hidden');
  imagePreview.style.backgroundImage = 'none';
  
  showToast('Product added successfully!', 'success');
  render();
}

function handleProductActions(e) {
  const target = e.target;
  const card = target.closest('.product-card');
  if (!card) return;
  
  const productId = card.dataset.id;
  
  // Handle Like
  if (target.closest('.btn-like')) {
    toggleLike(productId);
  }
  
  // Handle Delete
  if (target.closest('.btn-delete')) {
    deleteProduct(productId);
  }
}

function handleAddComment(e) {
  e.preventDefault();
  if (!e.target.classList.contains('comment-form')) return;
  
  const form = e.target;
  const input = form.querySelector('.comment-input');
  const text = input.value.trim();
  
  if (!text) return;
  
  const card = form.closest('.product-card');
  const productId = card.dataset.id;
  
  const product = products.find(p => p.id === productId);
  if (product) {
    product.comments.push({
      id: Date.now().toString(),
      text,
      createdAt: new Date().toISOString()
    });
    saveProducts();
    input.value = '';
    showToast('Comment added', 'info');
    render();
  }
}

// --- Actions ---
function toggleLike(id) {
  const product = products.find(p => p.id === id);
  if (product) {
    product.likes += 1;
    saveProducts();
    render();
  }
}

function deleteProduct(id) {
  if (confirm('Are you sure you want to delete this product?')) {
    products = products.filter(p => p.id !== id);
    saveProducts();
    showToast('Product deleted', 'info');
    render();
  }
}

// --- Toast Notification System ---
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  let icon = '';
  if (type === 'success') icon = '✓';
  else if (type === 'error') icon = '✕';
  else icon = 'ℹ';
  
  toast.innerHTML = `<span>${icon}</span> <span>${escapeHTML(message)}</span>`;
  toastContainer.appendChild(toast);
  
  setTimeout(() => {
    toast.classList.add('fade-out');
    toast.addEventListener('animationend', () => {
      toast.remove();
    });
  }, 3000);
}

// --- Rendering & Logic ---
function render() {
  const searchTerm = searchInput.value.toLowerCase();
  const filterCategory = categoryFilter.value;
  const sortBy = sortSelect.value;
  
  // 1. Filter
  let filteredProducts = products.filter(product => {
    const matchesSearch = product.title.toLowerCase().includes(searchTerm) || 
                          product.description.toLowerCase().includes(searchTerm);
    const matchesCategory = filterCategory === 'All' || product.category === filterCategory;
    return matchesSearch && matchesCategory;
  });
  
  // 2. Sort
  filteredProducts.sort((a, b) => {
    switch (sortBy) {
      case 'newest':
        return new Date(b.createdAt) - new Date(a.createdAt);
      case 'oldest':
        return new Date(a.createdAt) - new Date(b.createdAt);
      case 'price-asc':
        return a.price - b.price;
      case 'price-desc':
        return b.price - a.price;
      case 'likes-desc':
        return b.likes - a.likes;
      default:
        return 0;
    }
  });
  
  // 3. Update Dashboard Stats
  updateStats();
  
  // 4. Render DOM
  if (filteredProducts.length === 0) {
    productList.innerHTML = '';
    emptyState.classList.remove('hidden');
    return;
  }
  
  emptyState.classList.add('hidden');
  
  productList.innerHTML = filteredProducts.map(product => {
    const imageHTML = product.image 
      ? `<img src="${product.image}" alt="${escapeHTML(product.title)}" class="product-image">`
      : '';
      
    return `
      <article class="product-card" data-id="${product.id}">
        ${imageHTML}
        <div class="product-content">
          <div class="product-header">
            <h3 class="product-title">${escapeHTML(product.title)}</h3>
            <span class="product-price">$${product.price.toFixed(2)}</span>
          </div>
          <span class="product-category">${escapeHTML(product.category)}</span>
          <p class="product-desc">${escapeHTML(product.description)}</p>
          ${product.url ? `<a href="${escapeHTML(product.url)}" target="_blank" rel="noopener noreferrer" class="product-link">Visit Product ↗</a>` : ''}
          
          <div class="product-footer">
            <button class="btn-like ${product.likes > 0 ? 'liked' : ''}" aria-label="Like product">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
              </svg>
              ${product.likes}
            </button>
            <button class="btn-delete" aria-label="Delete product">
              <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
              </svg>
            </button>
          </div>
        </div>
        
        <div class="comments-section">
          ${product.comments.length > 0 ? `
            <ul class="comments-list">
              ${product.comments.map(comment => `
                <li class="comment-item">${escapeHTML(comment.text)}</li>
              `).join('')}
            </ul>
          ` : ''}
          <form class="comment-form">
            <input type="text" class="comment-input" placeholder="Add a comment..." required>
            <button type="submit" class="btn-comment">Post</button>
          </form>
        </div>
      </article>
    `;
  }).join('');
}

function updateStats() {
  // Total Products
  statTotal.textContent = products.length;
  
  // Total Likes
  const totalLikes = products.reduce((sum, product) => sum + product.likes, 0);
  statLikes.textContent = totalLikes;
  
  // Top Product
  if (products.length > 0) {
    const topProduct = [...products].sort((a, b) => b.likes - a.likes)[0];
    statTop.textContent = topProduct.likes > 0 ? topProduct.title : '-';
  } else {
    statTop.textContent = '-';
  }
  
  // Category Distribution
  const catCounts = products.reduce((acc, product) => {
    acc[product.category] = (acc[product.category] || 0) + 1;
    return acc;
  }, {});
  
  if (Object.keys(catCounts).length > 0) {
    statCategories.innerHTML = Object.entries(catCounts)
      .sort((a, b) => b[1] - a[1])
      .map(([cat, count]) => `
        <li>
          <span>${escapeHTML(cat)}</span>
          <span>${count}</span>
        </li>
      `).join('');
  } else {
    statCategories.innerHTML = '<li style="color: var(--text-secondary); font-size: 0.875rem;">No data</li>';
  }
}

// --- Utilities ---
function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// Start the app
init();

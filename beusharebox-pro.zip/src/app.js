/**
 * BEUShareBox Pro - Vanilla JS Application
 * Modular Architecture: State, UI, Events
 */

// --- STATE MANAGEMENT ---
const State = {
  products: [],
  user: {
    username: 'Guest',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix'
  },
  theme: 'light',
  filters: {
    category: 'all',
    search: '',
    sort: 'newest'
  },

  init() {
    // Load from localStorage
    const savedProducts = localStorage.getItem('beu_products');
    if (savedProducts) {
      this.products = JSON.parse(savedProducts);
    } else {
      // Default initial data
      this.products = [
        {
          id: Date.now(),
          name: 'Classic Mechanical Keyboard',
          price: 129.99,
          category: 'Electronics',
          desc: 'A tactile typing experience with RGB lighting and cherry blue switches.',
          image: 'https://picsum.photos/seed/keyboard/600/400',
          likes: 12,
          comments: ['Best keyboard ever!', 'Love the sound.'],
          createdAt: new Date().toISOString()
        },
        {
          id: Date.now() + 1,
          name: 'Minimalist Desk Lamp',
          price: 45.00,
          category: 'Home',
          desc: 'Sleek design with adjustable brightness and color temperature.',
          image: 'https://picsum.photos/seed/lamp/600/400',
          likes: 8,
          comments: ['Perfect for my home office.'],
          createdAt: new Date().toISOString()
        }
      ];
      this.save();
    }

    const savedUser = localStorage.getItem('beu_user');
    if (savedUser) this.user = JSON.parse(savedUser);

    const savedTheme = localStorage.getItem('beu_theme');
    if (savedTheme) this.theme = savedTheme;
  },

  save() {
    localStorage.setItem('beu_products', JSON.stringify(this.products));
    localStorage.setItem('beu_user', JSON.stringify(this.user));
    localStorage.setItem('beu_theme', this.theme);
  },

  addProduct(product) {
    this.products.unshift(product);
    this.save();
    UI.notify('Product added successfully!', 'success');
  },

  deleteProduct(id) {
    this.products = this.products.filter(p => p.id !== id);
    this.save();
    UI.notify('Product deleted.', 'error');
  },

  toggleLike(id) {
    const product = this.products.find(p => p.id === id);
    if (product) {
      product.isLiked = !product.isLiked;
      product.likes += product.isLiked ? 1 : -1;
      this.save();
      UI.notify(product.isLiked ? 'Liked!' : 'Unliked', 'success');
    }
  },

  addComment(id, comment) {
    const product = this.products.find(p => p.id === id);
    if (product) {
      product.comments.push(comment);
      this.save();
    }
  },

  updateOrder(newOrderIds) {
    const orderedProducts = newOrderIds.map(id => 
      this.products.find(p => p.id === parseInt(id))
    ).filter(Boolean);
    
    // Merge with any products not in the new order (safety)
    const remaining = this.products.filter(p => !newOrderIds.includes(p.id.toString()));
    this.products = [...orderedProducts, ...remaining];
    this.save();
  }
};

// --- UI RENDERING ---
const UI = {
  elements: {
    grid: document.getElementById('productGrid'),
    empty: document.getElementById('emptyState'),
    search: document.getElementById('searchInput'),
    sort: document.getElementById('sortSelect'),
    categoryFilters: document.getElementById('categoryFilters'),
    themeToggle: document.getElementById('themeToggle'),
    modalOverlay: document.getElementById('modalOverlay'),
    productFormModal: document.getElementById('productFormModal'),
    productDetailModal: document.getElementById('productDetailModal'),
    statsModal: document.getElementById('statsModal'),
    profileModal: document.getElementById('profileModal'),
    productForm: document.getElementById('productForm'),
    imageUploadArea: document.getElementById('imageUploadArea'),
    imagePreview: document.getElementById('imagePreview'),
    toastContainer: document.getElementById('toastContainer'),
    headerAvatar: document.getElementById('headerAvatar'),
    headerUsername: document.getElementById('headerUsername')
  },

  render() {
    const filtered = this.getFilteredProducts();
    this.elements.grid.innerHTML = '';
    
    if (filtered.length === 0) {
      this.elements.empty.classList.remove('hidden');
    } else {
      this.elements.empty.classList.add('hidden');
      filtered.forEach(product => {
        const card = this.createProductCard(product);
        this.elements.grid.appendChild(card);
      });
    }

    // Update Profile Mini
    this.elements.headerAvatar.src = State.user.avatar;
    this.elements.headerUsername.textContent = State.user.username;

    // Update Theme
    document.documentElement.setAttribute('data-theme', State.theme);
  },

  getFilteredProducts() {
    let result = [...State.products];

    // Search
    if (State.filters.search) {
      const term = State.filters.search.toLowerCase();
      result = result.filter(p => 
        p.name.toLowerCase().includes(term) || 
        p.desc.toLowerCase().includes(term)
      );
    }

    // Category
    if (State.filters.category !== 'all') {
      result = result.filter(p => p.category === State.filters.category);
    }

    // Sort
    switch (State.filters.sort) {
      case 'price-low': result.sort((a, b) => a.price - b.price); break;
      case 'price-high': result.sort((a, b) => b.price - a.price); break;
      case 'likes': result.sort((a, b) => b.likes - a.likes); break;
      case 'newest': default:
        result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    return result;
  },

  createProductCard(product) {
    const div = document.createElement('div');
    div.className = 'product-card';
    div.draggable = true;
    div.dataset.id = product.id;
    
    div.innerHTML = `
      <div class="card-image">
        <span class="card-category">${product.category}</span>
        <img src="${product.image || 'https://via.placeholder.com/300'}" alt="${product.name}" loading="lazy">
      </div>
      <div class="card-content">
        <div class="card-header">
          <h4>${product.name}</h4>
          <span class="card-price">$${product.price.toFixed(2)}</span>
        </div>
        <p class="card-desc">${product.desc}</p>
        <div class="card-footer">
          <div class="card-stats">
            <span class="stat-item like-btn ${product.isLiked ? 'liked' : ''}" data-id="${product.id}">
              ${product.isLiked ? '❤️' : '🤍'} ${product.likes}
            </span>
            <span class="stat-item comment-btn" data-id="${product.id}">
              💬 ${product.comments.length}
            </span>
          </div>
          <div class="card-actions">
            <button class="delete-btn" data-id="${product.id}" title="Delete">🗑️</button>
          </div>
        </div>
      </div>
    `;

    // Drag & Drop Events
    div.addEventListener('dragstart', (e) => {
      div.classList.add('dragging');
      e.dataTransfer.setData('text/plain', product.id);
    });

    div.addEventListener('dragend', () => {
      div.classList.remove('dragging');
      const newOrder = Array.from(this.elements.grid.querySelectorAll('.product-card'))
        .map(card => card.dataset.id);
      State.updateOrder(newOrder);
    });

    return div;
  },

  openModal(modalId) {
    this.elements.modalOverlay.classList.remove('hidden');
    document.querySelectorAll('.modal').forEach(m => m.classList.add('hidden'));
    document.getElementById(modalId).classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  },

  closeModals() {
    this.elements.modalOverlay.classList.add('hidden');
    document.querySelectorAll('.modal').forEach(m => m.classList.add('hidden'));
    document.body.style.overflow = '';
    // Reset forms
    this.elements.productForm.reset();
    this.elements.imagePreview.classList.add('hidden');
    document.querySelector('.upload-placeholder').classList.remove('hidden');
  },

  showProductDetail(id) {
    const product = State.products.find(p => p.id === parseInt(id));
    if (!product) return;

    document.getElementById('detailImg').src = product.image;
    document.getElementById('detailName').textContent = product.name;
    document.getElementById('detailPrice').textContent = `$${product.price.toFixed(2)}`;
    document.getElementById('detailCategory').textContent = product.category;
    document.getElementById('detailDesc').textContent = product.desc || 'No description provided.';
    document.getElementById('commentCount').textContent = product.comments.length;
    
    const list = document.getElementById('commentsList');
    list.innerHTML = product.comments.map(c => `<div class="comment-item">${c}</div>`).join('');
    
    document.getElementById('commentForm').dataset.id = product.id;
    this.openModal('productDetailModal');
  },

  showStats() {
    const total = State.products.length;
    const mostLiked = State.products.reduce((prev, current) => (prev.likes > current.likes) ? prev : current, {likes: 0, name: 'None'});
    
    const categories = State.products.reduce((acc, p) => {
      acc[p.category] = (acc[p.category] || 0) + 1;
      return acc;
    }, {});

    const statsHtml = `
      <div class="stat-card">
        <h4>Total Products</h4>
        <p>${total}</p>
      </div>
      <div class="stat-card">
        <h4>Most Liked</h4>
        <p>${mostLiked.name}</p>
      </div>
      <div class="stat-card" style="grid-column: span 2">
        <h4>Category Distribution</h4>
        <div style="display: flex; justify-content: space-around; margin-top: 1rem; font-size: 0.8rem;">
          ${Object.entries(categories).map(([cat, count]) => `
            <div><strong>${cat}</strong>: ${count}</div>
          `).join('')}
        </div>
      </div>
    `;
    
    document.getElementById('statsContainer').innerHTML = statsHtml;
    this.openModal('statsModal');
  },

  notify(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${type === 'success' ? '✅' : 'ℹ️'}</span> ${message}`;
    this.elements.toastContainer.appendChild(toast);
    
    setTimeout(() => {
      toast.style.animation = 'fadeOut 0.3s forwards';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }
};

// --- EVENT HANDLERS ---
const Events = {
  init() {
    // Search
    UI.elements.search.addEventListener('input', (e) => {
      State.filters.search = e.target.value;
      UI.render();
    });

    // Sort
    UI.elements.sort.addEventListener('change', (e) => {
      State.filters.sort = e.target.value;
      UI.render();
    });

    // Category Filter (Event Delegation)
    UI.elements.categoryFilters.addEventListener('click', (e) => {
      if (e.target.classList.contains('chip')) {
        document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        e.target.classList.add('active');
        State.filters.category = e.target.dataset.category;
        UI.render();
      }
    });

    // Theme Toggle
    UI.elements.themeToggle.addEventListener('click', () => {
      State.theme = State.theme === 'light' ? 'dark' : 'light';
      State.save();
      UI.render();
    });

    // Modals
    document.getElementById('addProductBtn').addEventListener('click', () => UI.openModal('productFormModal'));
    document.getElementById('statsBtn').addEventListener('click', () => UI.showStats());
    document.getElementById('userProfileBtn').addEventListener('click', () => UI.openModal('profileModal'));
    
    document.querySelectorAll('.close-modal').forEach(btn => {
      btn.addEventListener('click', () => UI.closeModals());
    });

    UI.elements.modalOverlay.addEventListener('click', (e) => {
      if (e.target === UI.elements.modalOverlay) UI.closeModals();
    });

    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') UI.closeModals();
    });

    // Product Form
    UI.elements.productForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const product = {
        id: Date.now(),
        name: document.getElementById('pName').value,
        price: parseFloat(document.getElementById('pPrice').value),
        category: document.getElementById('pCategory').value,
        desc: document.getElementById('pDesc').value,
        image: UI.elements.imagePreview.src || 'https://via.placeholder.com/300',
        likes: 0,
        comments: [],
        createdAt: new Date().toISOString()
      };
      State.addProduct(product);
      UI.closeModals();
      UI.render();
    });

    // Image Upload
    UI.elements.imageUploadArea.addEventListener('click', () => document.getElementById('pImage').click());
    document.getElementById('pImage').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          UI.elements.imagePreview.src = event.target.result;
          UI.elements.imagePreview.classList.remove('hidden');
          document.querySelector('.upload-placeholder').classList.add('hidden');
        };
        reader.readAsDataURL(file);
      }
    });

    // Drag & Drop Grid Reordering
    UI.elements.grid.addEventListener('dragover', (e) => {
      e.preventDefault();
      const draggingItem = document.querySelector('.dragging');
      const siblings = [...UI.elements.grid.querySelectorAll('.product-card:not(.dragging)')];
      const nextSibling = siblings.find(sibling => {
        return e.clientY <= sibling.offsetTop + sibling.offsetHeight / 2;
      });
      UI.elements.grid.insertBefore(draggingItem, nextSibling);
    });

    // Grid Actions (Event Delegation)
    UI.elements.grid.addEventListener('click', (e) => {
      const id = e.target.dataset.id;
      
      if (e.target.classList.contains('delete-btn')) {
        if (confirm('Are you sure you want to delete this product?')) {
          State.deleteProduct(parseInt(id));
          UI.render();
        }
        return;
      }

      if (e.target.classList.contains('like-btn')) {
        State.toggleLike(parseInt(id));
        UI.render();
        return;
      }

      // Open Detail
      const card = e.target.closest('.product-card');
      if (card && !e.target.closest('.card-actions') && !e.target.closest('.card-stats')) {
        UI.showProductDetail(card.dataset.id);
      }
    });

    // Comment Form
    document.getElementById('commentForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const id = parseInt(e.target.dataset.id);
      const input = document.getElementById('commentInput');
      if (input.value.trim()) {
        State.addComment(id, input.value.trim());
        input.value = '';
        UI.showProductDetail(id);
        UI.render();
      }
    });

    // Profile Form
    document.getElementById('profileForm').addEventListener('submit', (e) => {
      e.preventDefault();
      State.user.username = document.getElementById('usernameInput').value || 'Guest';
      State.save();
      UI.closeModals();
      UI.render();
      UI.notify('Profile updated!', 'success');
    });

    document.getElementById('avatarUploadArea').addEventListener('click', () => document.getElementById('avatarInput').click());
    document.getElementById('avatarInput').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          State.user.avatar = event.target.result;
          document.getElementById('profileAvatarPreview').src = event.target.result;
        };
        reader.readAsDataURL(file);
      }
    });

    // Export
    document.getElementById('exportBtn').addEventListener('click', () => {
      const data = JSON.stringify({ products: State.products, user: State.user });
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `beusharebox_export_${Date.now()}.json`;
      a.click();
      UI.notify('Data exported successfully!');
    });

    // Import
    document.getElementById('importFile').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          try {
            const data = JSON.parse(event.target.result);
            if (data.products) {
              State.products = [...data.products, ...State.products].filter((v, i, a) => a.findIndex(t => t.id === v.id) === i);
              State.save();
              UI.render();
              UI.notify('Data imported and merged!', 'success');
            }
          } catch (err) {
            UI.notify('Invalid JSON file.', 'error');
          }
        };
        reader.readAsDataURL(file);
      }
    });

    // Keyboard Shortcuts
    window.addEventListener('keydown', (e) => {
      if (e.key === '/' && document.activeElement !== UI.elements.search) {
        e.preventDefault();
        UI.elements.search.focus();
      }
    });
  }
};

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
  State.init();
  Events.init();
  UI.render();
});
